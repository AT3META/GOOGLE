<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Viewport for Translate">
	<title>TRANSLATE</title>
</head><body>
<p>TRANSLATE WEBSITE</p>
<div id="google_translate_element"></div>
<script type="text/javascript">// <![CDATA[
function googleTranslateElementInit() {
new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
// ]]></script>
<script src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit" type="text/javascript"></script>
<p></p><p>_________________________________</p>
<p>TRANSLATE DIALOGUE</p>
	<button class="btn btn-primary" align="center" onclick="NewTab()"> 
    OPEN TRANSLATE 
    </button> 
    <script> 
        function NewTab() { 
            window.open("https://translate.google.com/translate?", 
                    "", "width=850, height=650"); 
        } 
    </script>
</body>