<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Viewport for Maps">
	<title>MAPS</title>
</head>
<body>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1587470.8199997619!2d-105.09345129081036!3d39.00324588122606!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87135cfd343aa831%3A0xf3b632216c347ce2!2sCheyenne%20Mountain!5e0!3m2!1sen!2sus!4v1626684006576!5m2!1sen!2sus" width="650" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
	<button class="btn btn-primary" align="center" onclick="NewTab()"> 
    FULLSCREEN 
    </button> 
    <script> 
        function NewTab() { 
            window.open("https://maps.google.com", 
                    "", "width=850, height=650"); 
        } 
    </script>
</body>