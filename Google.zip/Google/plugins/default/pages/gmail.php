<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Viewport for Gmail">
	<title>GMAIL</title>
	<script src="https://unpkg.com/@ungap/custom-elements-builtin"></script>
	<script src="x-frame-bypass.js" type="module"></script>
	<script type="module" src="https://unpkg.com/x-frame-bypass"></script>
</head>
<body>
<iframe is="x-frame-bypass" src="https://mail.google.com" float="left" frameborder="0" scrolling="auto" width="888" height="666" allowfullscreen></iframe>
	<button class="btn btn-primary" align="center" onclick="NewTab()"> 
    FULLSCREEN 
    </button> 
    <script> 
        function NewTab() { 
            window.open("https://mail.google.com", 
                    "", "width=888, height=666"); 
        } 
    </script>
</body>