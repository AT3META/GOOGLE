<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Viewport for News">
	<title>NEWS</title>
</head>
<body>
<iframe src="https://news.google.com/" float="left" frameborder="0" scrolling="auto" width="650" height="450" allowfullscreen></iframe>
	<button class="btn btn-primary" align="center" onclick="NewTab()"> 
    FULLSCREEN 
    </button> 
    <script> 
        function NewTab() { 
            window.open("https://news.google.com/", 
                    "", "width=850, height=650"); 
        } 
    </script>
</body>