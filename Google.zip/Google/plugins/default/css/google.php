.menu-section-google i:before {
    font-family: FontAwesome;
    content: "\f1a0";
}
.menu-section-item-search:before {
    font-family: FontAwesome;
    content: "\f002";
}
.menu-section-item-gmail:before {
    font-family: FontAwesome;
    content: "\f0e0";
}
.menu-section-item-maps:before {
    font-family: FontAwesome;
    content: "\f276";
}
.menu-section-item-translate:before {
    font-family: FontAwesome;
    content: "\f0ac";
}